import React from 'react';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import { GoDotFill } from "react-icons/go";

function Gallery() {
    return (
        <Container fluid className='g-0 py-5 section-bg'>
            <Container>
                <Row className='g-0'>
                    <Col>
                        <div className='text-center'>
                            <h6 className='opacity-50 mb-3'> GALLERY </h6>
                            <h3 className='text-uppercase mb-5'> CHEAK <span className='Real-color'>OUR GALLERY</span></h3>
                        </div>
                    </Col>
                </Row>
                <Row className='justify-content-between gy-4'>
                    <Col className='col-lg-2 mx-lg-3 col-sm-4 col-12'>
                        <div>
                            <img src="https://bootstrapmade.com/demo/templates/Yummy/assets/img/gallery/gallery-1.jpg" alt="" className='img-fluid' />
                        </div>
                    </Col>
                    <Col className='col-lg-2 mx-lg-3 col-sm-4 col-12'>
                        <div>
                            <img src="https://bootstrapmade.com/demo/templates/Yummy/assets/img/gallery/gallery-2.jpg" alt="" className='img-fluid' />
                        </div>
                    </Col>
                    <Col className='col-lg-2 mx-lg-3 col-sm-4 col-12'>
                        <div className='Real-Red-Full p-1'>
                            <img src="https://bootstrapmade.com/demo/templates/Yummy/assets/img/gallery/gallery-3.jpg" alt="" className='img-fluid' />
                        </div>
                    </Col>
                    <Col className='col-lg-2 mx-lg-3 col-sm-4 col-12'>
                        <div>
                            <img src="https://bootstrapmade.com/demo/templates/Yummy/assets/img/gallery/gallery-4.jpg" alt="" className='img-fluid' />
                        </div>
                    </Col>
                    <Col className='col-lg-2 mx-lg-3 col-sm-4 col-12'>
                        <div>
                            <img src="https://bootstrapmade.com/demo/templates/Yummy/assets/img/gallery/gallery-5.jpg" alt="" className='img-fluid' />
                        </div>
                    </Col>
                </Row>
                <Row className='g-0'>
                    <Col>
                        <div className='text-center my-4'>
                            <h4>
                                <GoDotFill className='text-secondary fs-5' />
                                <GoDotFill className='text-secondary fs-5' />
                                <GoDotFill className='text-secondary fs-5' />
                                <GoDotFill className='Real-color fs-5' />
                                <GoDotFill className='text-secondary fs-5' />
                                <GoDotFill className='text-secondary fs-5' />
                                <GoDotFill className='text-secondary fs-5' />
                            </h4>
                        </div>
                    </Col>
                </Row>
            </Container>
        </Container>
    )
}

export default Gallery;
