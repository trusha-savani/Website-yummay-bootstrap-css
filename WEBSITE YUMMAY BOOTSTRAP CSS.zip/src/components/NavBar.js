import React from 'react';
import Button from 'react-bootstrap/Button';
import Container from 'react-bootstrap/Container';
import Form from 'react-bootstrap/Form';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';

function NavBar() {
  return (
    <Container fluid className='g-0'>
      <Container>
        <Row>
          <Col>
            <Navbar expand="lg" className="py-3">
              <Container fluid className='p-0'>
                <Navbar.Brand href="#"> <h2 className='fw-bold'>  Yummy <span className='Real-color'>.</span> </h2> </Navbar.Brand>
                <Navbar.Toggle aria-controls="navbarScroll" />
                <Navbar.Collapse id="navbarScroll">
                  <Nav className="mx-auto my-2 my-lg-0" style={{ maxHeight: '100px' }} navbarScroll>
                    <Nav.Link className='mx-2 fw-medium' href="#action1">Home</Nav.Link>
                    <Nav.Link className='mx-2 fw-medium' href="#action2">About</Nav.Link>
                    <Nav.Link className='mx-2 fw-medium' href="#action3">Menu</Nav.Link>
                    <Nav.Link className='mx-2 fw-medium' href="#action4">Events</Nav.Link>
                    <Nav.Link className='mx-2 fw-medium' href="#action5">Chefs</Nav.Link>
                    <Nav.Link className='mx-2 fw-medium' href="#action6">Gallery</Nav.Link>
                    <NavDropdown className='mx-2 fw-medium' title="Drop Down" id="navbarScrollingDropdown">
                      <NavDropdown.Item href="#action0" className='fw-medium'>Action</NavDropdown.Item>
                      <NavDropdown.Item href="#action40" className='fw-medium'>
                        Another action
                      </NavDropdown.Item>
                      <NavDropdown.Divider />
                      <NavDropdown.Item href="#action5" className='fw-medium'>
                        Something else here
                      </NavDropdown.Item>
                    </NavDropdown>
                    <Nav.Link className='mx-2 fw-medium' href="#action7">Contact</Nav.Link>
                  </Nav>
                  <Form className="d-flex justify-content-center mt-lg-auto mt-md-3 mt-sm-3">
                    <Button className="Real border-0 Nav-Btn px-4"> Book Table </Button>
                  </Form>
                </Navbar.Collapse>
              </Container>
            </Navbar>
          </Col>
        </Row>
      </Container>
    </Container>
  )
}

export default NavBar;
