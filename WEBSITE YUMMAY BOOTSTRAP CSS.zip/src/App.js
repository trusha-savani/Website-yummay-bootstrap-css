import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import NavBar from './components/NavBar';
import Enjoy from './components/Enjoy';
import AboutUs from './components/AboutUs';
import RedCard from './components/RedCard';
import Numbers from './components/Numbers';
import FoodMenu from './components/FoodMenu';
import Testimonials from './components/Testimonials';
import Events from './components/Events';
import Chefs from './components/Chefs';
import BookTable from './components/BookTable';
import Gallery from './components/Gallery';
import Contact from './components/Contact';
import Footer from './components/Footer';

function App() {
  return (
    <div> 
      <NavBar/>
      <Enjoy/>
      <AboutUs/>
      <RedCard/>
      <Numbers/>
      <FoodMenu/>
      <Testimonials/>
      <Events/>
      <Chefs/>
      <BookTable/>
      <Gallery/>
      <Contact/>
      <Footer/>
    </div>
  );
}

export default App;
